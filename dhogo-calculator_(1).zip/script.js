// Countdown logic
let count = 5;
const countdown = document.getElementById('countdown');
const timer = setInterval(() => {
  count--;
  countdown.innerText = count;
  if (count <= 0) clearInterval(timer);
}, 1000);

// Calculator logic
let result = '';
let display = document.getElementById('result');
const buttons = document.querySelectorAll('button');

buttons.forEach(btn => {
  btn.addEventListener('click', () => {
    const val = btn.innerText;

    if (val === 'C') {
      result = '';
      display.innerText = '';
    } else if (val === '=') {
      try {
        display.innerText = eval(result);
        result = '';
      } catch {
        display.innerText = 'Error';
        result = '';
      }
    } else {
      result += val;
      display.innerText = result;
    }
  });
});
